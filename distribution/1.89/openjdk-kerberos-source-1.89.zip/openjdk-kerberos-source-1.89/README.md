# Corresponding source: OpenJDK Kerberos in Kerberos Authenticator 1.89

Release: v1.89
Release commit: 9da8b717e1374eb1cc4e6fcb4fbd46cd0f7f2633

This archive contains the complete modified openjdk-kerberos module shipped in this release, including source headers, tests, license and Gradle build scripts. The standalone settings omit the independent Android app module. No private repository access is required.

License: GPL version 2 with the Classpath exception where designated in individual source headers; see openjdk-kerberos/LICENSE. Original attribution notices are retained. Upstream: https://github.com/google/openjdk-kerberos.

Local changes include Android packaging, Kerberos crypto support, referrals, peer-error parsing and SPNEGO context handling.

## Build

Install JDK 17 and Android SDK platform 35 / build-tools 35.0.0. Set JAVA_HOME to JDK 17 and ANDROID_HOME to the SDK directory. Internet access is needed to download public Gradle/Maven dependencies.

```sh
chmod +x gradlew
./gradlew :openjdk-kerberos:assembleRelease
```

Output: openjdk-kerberos/build/outputs/aar/openjdk-kerberos-release.aar. This builds the library, not the independently licensed application APK. Installing an application containing your modified library requires building and signing that application separately; the publisher's private signing key is not included.
