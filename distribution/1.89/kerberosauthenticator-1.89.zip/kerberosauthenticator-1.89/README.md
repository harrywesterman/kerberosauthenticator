# Kerberos Authenticator 1.89 for Android

This package contains the signed Android application, administrator instructions, license notices and a written source offer. Application source code is not included.

## Requirements and installation

Android 8.0 or newer (API 26+), Android Enterprise management and an MDM/EMM that supports Android managed application configuration are required. The device must reach the organization's AD DNS, Kerberos KDCs, HTTPS services and SMB servers, using a VPN where needed. HTTPS services need certificates trusted by Android/Chrome.

Distribute kerberosauthenticator-1.89.apk through your MDM as an internal application or your organization's approved private-app process. Install the authenticator and Chrome in the same Android profile. The package ID is com.poelbos.kerberosauthenticator. Update an existing installation in place; do not uninstall or clear its data. A compatible signing certificate is required for updates. For an authorized USB installation use `adb install -r kerberosauthenticator-1.89.apk`.

## Managed configuration

Configure the authenticator using its embedded managed-configuration schema. Start with managed-configuration.example.json, replacing all example domain and share values. Never distribute a password through MDM. The user opens Kerberos Authenticator and enters their own AD credentials.

Configure Chrome with:

| Policy | Value |
|---|---|
| AuthAndroidNegotiateAccountType | AndroidEnterpriseKerberos |
| AuthSchemes | negotiate |
| AuthServerAllowlist | *.example.com,example.com (replace with approved hosts) |
| DisableAuthNegotiateCnameLookup | true |

Allow Chrome's Contacts permission where Android requires it for AccountManager account discovery. The authenticator's notification permission is optional for sign-in alerts. Servers must support HTTP Negotiate and have the appropriate HTTP service principal registered in AD; browser policy alone cannot enable server-side Kerberos. Do not bypass certificate errors.

## Everyday use

Open the authenticator to sign in, inspect ticket validity, refresh or sign out. Managed shares appear as storage locations in Android Files and the system file picker. Apps in the same profile can open and save documents using this picker. Creating folders, renaming and deleting remain subject to AD permissions. SMB uses Kerberos only; the example requires SMB encryption. There is no offline synchronization.

External applications may save their own copies or capture their own screens. The authenticator's screenshot and local-cache settings do not control those applications. Use Android Enterprise policies to control profile boundaries and data sharing. Disabling shares, changing configuration or signing out invalidates access to affected documents.

## Troubleshooting

Check VPN, internal DNS, device time, trusted HTTPS certificates, AD account access and MDM assignments. For missing Chrome authentication, verify the server returns a Negotiate challenge, Chrome's policies and account-discovery permission. For missing shares, check enable_shares and sign-in status. Network interruptions and AD access denials are returned to the calling application.

## Licenses and source

Read LICENSES and SOURCE_OFFER.txt. The source offer is available to any third party by email; access to a private repository is not required. Keep these documents with redistributed copies. SHA256SUMS allows verification of the files in this package.
